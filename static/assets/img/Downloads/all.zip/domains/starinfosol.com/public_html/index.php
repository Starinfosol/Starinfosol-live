<?php

// require "config.php";
session_start();

if (!isset($_SESSION['username'])) {
    //   header("Location: index.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <!-- <title>Home | Starinfosol</title> -->
  <title> Home | Starinfosol</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon001.png" rel="icon">
  <link href="assets/img/apple-touch-icon001.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  
  <script data-ad-client="ca-pub-2002299671964701" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

</head>

<body>

  <!-- ======= Top Bar ======= -->
  <!-- <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
      <div class="align-items-center d-none d-md-flex">
        <i class="bi bi-clock"></i> Monday - Saturday, 8AM to 10PM
      </div>
      <div class="d-flex align-items-center">
        <i class="bi bi-phone"></i> Call us now +1 5589 55488 55
      </div>
    </div>
  </div> -->


  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center me-auto bi-arrow-up-short">
          <a href="info@starinfosol.com">info@starinfosol.com</a></i>
          <i class="bi bi-clock"></i> Time : 8AM to 10PM
          <!--<i class="bi bi-clock"></i> Monday - Saturday, Time : 8AM to 10PM-->
        <!--<i class="bi bi-phone d-flex align-items-center ms-4"><span>+91 9074919296</span></i>-->
      </div>
        <?php echo "<h6>" . $_SESSION['username'] . "</h6>"; ?>
      <div class="social-links d-none d-md-flex">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i> </a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i> </a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i> </a>
        <a href="https://wa.me/message/H72CPSV3OZMAE1" class="whatsapp"><i class="bi bi-whatsapp"></i> </a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i> </a>
         <!--<b href="#" class="google-plus"><i class="bi bi-skype"></i></b> -->
      </div>
    </div>
  </div>


  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="index.php" class="logo me-auto"><img src="assets/img/stara.png" alt=""></a>
      <!-- <a href="/" class="logo me-auto" alt="">Starinfosol</a> -->
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <h1 class="logo me-auto"><a href="index.html">Medicio</a></h1> -->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto " href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#doctors">Team</a></li>
          <li><a class="nav-link scrollto" href="#testimonials">Testimonials</a></li>
          <!-- <li><a class="nav-link scrollto" href="jarvis.html">AI</a></li> -->
          <li class="dropdown"><a href="#"><span>Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <!-- <li><a href="#services">Services</a></li> -->
              <li class="dropdown"><a href="/services"><span>Services</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Electrician</a></li>
                  <li><a href="#">Driver</a></li>
                  <li><a href="#">Photo shoot</a></li>
                  <li><a href="#">Tours & Travels</a></li>
                  <li><a href="#">Agricultural Services</a></li>
                  <li><a href="#">Construction work</a></li>
                  <li><a href="#">Repairing</a></li>
                  <li><a href="#">Grocery delivery</a></li>
                  <li><a href="#">Other Services</a></li>
                </ul>
              </li>
              <li class="dropdown"><a href="/health"><span>Health</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#doctors">Doctors</a></li>
                  <li><a href="#departments">Departments</a></li>
                  <li><a href="#">Medicine</a></li>
                  <li><a href="#">physiotherapy</a></li>
                  <li><a href="#">pathology</a></li>
                </ul>
              </li>
              <li><a href="#departments">Technical</a></li>
              <li><a href="#gallery">Gallery</a></li>
              <li><a href="#pricing">Pricing</a></li>
              <li><a href="#faq">FAQ</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="blogs.html">Blogs</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

        <a href="#appointment" class="appointment-btn scrollto"><span class="d-none d-md-inline">Make an </span>Appointment</a>
        <a href="login.php" type="button" data-toggle="modal" class="appointment-btn scrollto"><span class="d-none d-md-inline"></span>Login</a>
        
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(assets/img/slide/slide-001.jpg)">
          <div class="container">
            <h2>Welcome to <span>Starinfosol</span></h2>
            <h6>Fastest And Most Efficient Work</h6>
            <a href="#about" class="btn-get-started scrollto">Read More</a>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-002.jpg)">
          <div class="container">
            <h2>Build and grow</h2>
            <h6>Get all your essential services in one place.</h6>
            <a href="#about" class="btn-get-started scrollto">Read More</a>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-003.jpg)">
          <div class="container">
            <h2>Complete your Dreams</h2>
            <h6>Home Services provider to provide your essential services</h6>
            <a href="#about" class="btn-get-started scrollto">Read More</a>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
  </section><!-- End Hero -->


  <main id="main">
    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
              <div class="icon"><i class="fas fa-heartbeat"></i></div>
              <h4 class="title"><a href="">Doctors</a></h4>
              <p class="description">Source for Healthcare Information</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <div class="icon"><i class="fas fa-pills"></i></div>
              <h4 class="title"><a href="">Medicines</a></h4>
              <p class="description">medical information written for you to make informed decisions about your health
                concerns.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
              <div class="icon"><i class="fas fa-thermometer"></i></div>
              <h4 class="title"><a href="">Pathology</a></h4>
              <p class="description">Pathology is the study of the causes and effects of disease or injury.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
              <div class="icon"><i class="fas fa-dna"></i></div>
              <h4 class="title"><a href="">Covid-19</a></h4>
              <p class="description">Stay home if you feel unwell.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Featured Services Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container" data-aos="zoom-in">

        <div class="text-center">
          <h3>In an emergency? Need help now?</h3>
          <p> If you have booked the service and for any reason you do not want the service, then no matter you can
            cancel your booking at any time.</p>
          <a class="cta-btn scrollto" href="#appointment">Make an Make an Appointment</a>
        </div>

      </div>
    </section><!-- End Cta Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About Us</h2>
          <p> Welcome to Starinfosol - do you need a job, we are providing you a platform where you can join us and take
            a
            training of some of the various services we provide and join us to create a better future for you.</p>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-right">
            <a href="#"><img src="assets/img/about.jpg" class="img-fluid" alt=""></a>
          </div>

          <div class="col-lg-6 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3>GET ALL YOUR ESSENTIAL SERVICES IN ONE PLACE</h3>
            <p class="fst-italic"> Starinfosol mission is to offer residents of the Local area the best service in the
              area. We are committed to providing the service quality and value that our customers expect. To improve
              your
              strength and grow up your personality. Self-motivated and hardworking with positive attitude towards
              career
              and life. To provide services, every member of our team is fully trained and our team provides better
              services with taking care of your safety. Provides you advanced and long-lasting services. Our team always
              remains ready to provide you better services in shorter time. Your security is first attention of our
              team.
            </p>
            <ul>
              <li><i class="bi bi-check-circle"></i> We utilize your feedback to improve quality of our services.</li>
              <li><i class="bi bi-check-circle"></i> Your information is completely Safe and secure by starinfosl.</li>
              <li><i class="bi bi-check-circle"></i> No time restriction, we work 24x7. Our availability is according to
                your convenience.</li>
            </ul>
            <p>
              If you are experienced in any service and you need some medium to give your service, then you can join us
              and give your service, now you do not need any shop to serve you nor do you need to wander here and there.
              We give you a platform where you can make more money by using your art and experience in the best way, we
              provide you service in your own area through us. If you want to join us then join now.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container" data-aos="fade-up">

        <div class="row no-gutters">

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="fas fa-user-md"></i>
              <span data-purecounter-start="0" data-purecounter-end="60" data-purecounter-duration="1"
                class="purecounter"></span>

              <p><strong>Doctors</strong> Healthcare</p>
              <a href="#">Find out more &raquo;</a>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="far fa-hospital"></i>
              <span data-purecounter-start="0" data-purecounter-end="20" data-purecounter-duration="1"
                class="purecounter"></span>
              <p><strong>Departments</strong> Multiple type of Services, inculding Healthcare</p>
              <a href="#">Find out more &raquo;</a>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="fas fa-flask"></i>
              <span data-purecounter-start="0" data-purecounter-end="14" data-purecounter-duration="1"
                class="purecounter"></span>
              <p><strong>Research Lab</strong> "creative and systematic work undertaken to increase the stock of
                knowledge"</p>
              <a href="#">Find out more &raquo;</a>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="fas fa-award"></i>
              <span data-purecounter-start="0" data-purecounter-end="150" data-purecounter-duration="1"
                class="purecounter"></span>
              <p><strong>Awards</strong> that recognize and promote the talen</p>
              <a href="#">Find out more &raquo;</a>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-6 order-2 order-lg-1" data-aos="fade-right">
            <div class="icon-box mt-5 mt-lg-0">
              <i class="bx bx-receipt"></i>
              <h4>Friendly behavior</h4>
              <p>Our team has been given special training and is fully prepared to provide you with developed services.
              </p>
            </div>
            <div class="icon-box mt-5">
              <i class="bx bx-cube-alt"></i>
              <h4>Advanced services</h4>
              <p>Our team provides you with advanced services. And Provides long lasting services.</p>
            </div>
            <div class="icon-box mt-5">
              <i class="bx bx-images"></i>
              <h4>Gallery</h4>
              <p>Our team always remains ready to provide you better services in shorter time. Your security is first
                attention of our team.</p>
            </div>
            <div class="icon-box mt-5">
              <i class="bx bx-shield"></i>
              <h4>Your safety is our priority</h4>
              <p>Every member of our team is fully trained and our team provides better services while taking care of
                your
                safety.</p>
            </div>
          </div>
          <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in">
            <img src="assets/img/features0954.jpg" class="img-fluid" alt="">
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p>Your safety is our priority</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon"><i class="bi bi-briefcase"></i></div>
            <h4 class="title"><a href="">Multiple services</a></h4>
            <p class="description">There is no need to contact different people for different services. Get all your
              essential services in one place.</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon"><i class="bi bi-card-checklist"></i></div>
            <h4 class="title"><a href="">Quick Services</a></h4>
            <p class="description">Save your precious time to go out, no need to waste time by wandering around for
              service, book your service in few minutes.</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon"><i class="bi bi-bar-chart"></i></div>
            <h4 class="title"><a href="">Qualified Services</a></h4>
            <p class="description">To provide you services, we have prepared a team of experienced employees.</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon"><i class="bi bi-binoculars"></i></div>
            <h4 class="title"><a href="">Customer Feedback</a></h4>
            <p class="description">We utilize your feedback to improve quality of our services.</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon"><i class="bi bi-brightness-high"></i></div>
            <h4 class="title"><a href="">freedom</a></h4>
            <p class="description">If you have booked the service and for any reason you do not want the service, then
              no
              matter you can cancel your booking at any time.</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon"><i class="bi bi-calendar4-week"></i></div>
            <h4 class="title"><a href="">24x7 availability</a></h4>
            <p class="description">No time restriction, we work 24x7. Our availability is according to your convenience.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Appointment Section ======= -->
    <section id="appointment" class="appointment section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Make an Appointment</h2>
          <p>Save your precious time to go out, no need to waste time by wandering around for service, book your service
            in few minutes.</p>
        </div>

        <form id="appointment-form" action="https://formspree.io/f/xoqyjovv" method="POST"role="form" class="php-email-form" data-aos="fade-up" data-aos-delay="100">
          <div class="row">
          <div class="row">
            <div class="col-md-4 form-group">
              <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
            </div>
            <div class="col-md-4 form-group mt-3 mt-md-0">
              <input type="tel" class="form-control" name="phone" id="phone" placeholder="Your Phone" required>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 form-group mt-3">
              <input type="datetime" name="date" class="form-control datepicker" id="date"
                placeholder="Appointment Date" required>
            </div>
            <div class="col-md-4 form-group mt-3">
              <select name="department" id="department" class="form-select">
                <option value="">Select Department</option>
                <option value="Allopathic">Allopathic</option>
                <option value="Homeopathy">Homeopathy</option>
                <option value="Ayurvedic">Ayurvedic</option>
              </select>
            </div>
            <div class="col-md-4 form-group mt-3">
              <select name="doctor" id="doctor" class="form-select">
                <option value="">Select Doctor</option>
                <option value="Dr. Bhuvneshwer Janghela">Dr. Bhuvneshwer</option>
                <option value="Dr. Ishwari Verma">Dr. Ishwari</option>
                <option value="Dr. Shriwastav">Dr. Shriwastav</option>
              </select>
            </div>
          </div>

          <div class="form-group mt-3">
            <textarea class="form-control" name="message" rows="5" placeholder="Message (Optional)"></textarea>
          </div>
          <!--<div class="my-3">-->
          <!--  <div class="loading">Loading</div>-->
          <!--  <div class="error-message"></div>-->
          <!--  <div class="sent-message">Your appointment request has been sent successfully. Thank you!</div>-->
          <!--</div>-->
          <div class="text-center"><button id="appointment-form-button" type="submit">Make an Appointment</button></div>
          <p class="text-center my-3" data-aos="zoom-in" id="appointment-form-status"></p>
        </form>

      </div>
    </section><!-- End Appointment Section -->

    <!-- ======= Departments Section ======= -->
    <section id="departments" class="departments">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Departments</h2>
          <p>Departmentalization, division of a larger organization into parts with specific responsibility.</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-4 mb-5 mb-lg-0">
            <ul class="nav nav-tabs flex-column">
              <li class="nav-item">
                <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#tab-1">
                  <h4>Cardiology</h4>
                  <p>Cardiac electrophysiology is the science of elucidating, diagnosing, and treating the electrical
                    activities of the heart.</p>
                </a>
              </li>
              <li class="nav-item mt-2">
                <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2">
                  <h4>Neurology</h4>
                  <p>These can affect the central nervous system (brain and spinal cord), the peripheral nervous system,
                    the autonomic nervous system, and the muscular system.</p>
                </a>
              </li>
              <li class="nav-item mt-2">
                <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3">
                  <h4>Homeopathy</h4>
                  <p>Homeopathy or homoeopathy is a pseudoscientific system of alternative medicine.</p>
                </a>
              </li>
              <li class="nav-item mt-2">
                <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4">
                  <h4>Allopathic</h4>
                  <p>Allopathic medicine, or allopathy, refers to science-based, modern medicine.</p>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-lg-8">
            <div class="tab-content">
              <div class="tab-pane active show" id="tab-1">
                <h3>Cardiology</h3>
                <p class="fst-italic">Cardiac electrophysiology is the science of elucidating, diagnosing, and treating
                  the electrical activities of the heart.</p>
                <img src="assets/img/departments-1.jpg" alt="" class="img-fluid">
                <p>Cardiology (from Greek καρδίᾱ kardiā, "heart" and -λογία -logia, "study") is a branch of medicine
                  that deals with the disorders of the heart as well as some parts of the circulatory system. The field
                  includes medical diagnosis and treatment of congenital heart defects, coronary artery disease, heart
                  failure, valvular heart disease and electrophysiology. Physicians who specialize in this field of
                  medicine are called cardiologists, a specialty of internal medicine. Pediatric cardiologists are
                  pediatricians who specialize in cardiology.</p>
              </div>
              <div class="tab-pane" id="tab-2">
                <h3>Neurology</h3>
                <p class="fst-italic">These can affect the central nervous system (brain and spinal cord), the
                  peripheral nervous system, the autonomic nervous system, and the muscular system.</p>
                <img src="assets/img/departments-2.jpg" alt="" class="img-fluid">
                <p>A neurologist is a physician specializing in neurology and trained to investigate, or diagnose and
                  treat neurological disorders.[2] Neurologists may also be involved in clinical research, clinical
                  trials, and basic or translational research. While neurology is a nonsurgical specialty, its
                  corresponding surgical specialty is neurosurgery.[2]</p>
              </div>
              <div class="tab-pane" id="tab-3">
                <h3>Homeopathy</h3>
                <p class="fst-italic">Homeopathy or homoeopathy is a pseudoscientific system of alternative medicine.
                </p>
                <img src="assets/img/departments-3.jpg" alt="" class="img-fluid">
                <p>Homeopathy or homoeopathy is a pseudoscientific[1][2][3][4] system of alternative medicine. It was
                  conceived in 1796 by the German physician Samuel Hahnemann. Its practitioners, called homeopaths,
                  believe that a substance that causes symptoms of a disease in healthy people can cure similar symptoms
                  in sick people; this doctrine is called similia similibus curentur, or "like cures like".</p>
              </div>
              <div class="tab-pane" id="tab-4">
                <h3>Allopathic</h3>
                <p class="fst-italic">Allopathic medicine, or allopathy, refers to science-based, modern medicine.</p>
                <img src="assets/img/departments-4.jpg" alt="" class="img-fluid">
                <p>Allopathic medicine, or allopathy, refers to science-based, modern medicine.[1][2] There are regional
                  variations in usage of the term. In the United States, the term is used to contrast with osteopathic
                  medicine, especially in the field of medical education.</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Departments Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Testimonials</h2>
          <p>Provides you advanced and long-lasting services. Our team always remains ready to provide you better
            services
            in shorter time. Your security is first attention of our team.</p>
        </div>

        <div class="testimonials-slider swiper-container" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  To improve your strength and grow up your personality. Self-motivated and hardworking with positive
                  attitude towards career and life.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-001.jpg" class="testimonial-img" alt="">
                <h3>Pro. Shubham Verma</h3>
                <h4>Ceo &amp; Founder</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Starinfosol mission is to offer residents of the Local area the best service in the area. We are
                  committed to providing the service quality and value that our customers expect.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-002.jpg" class="testimonial-img" alt="">
                <h3>Rahul Namdev</h3>
                <h4>Designer</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  To provide services, every member of our team is fully trained and our team provides better services
                  with taking care of your safety.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-003.jpg" class="testimonial-img" alt="">
                <h3>Manoj verma</h3>
                <h4>Invester</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Provides you advanced and long-lasting services. Our team always remains ready to provide you better
                  services in shorter time. Your security is first attention of our team.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-004.jpg" class="testimonial-img" alt="">
                <h3>Dr. Bhuvneshwer janghela</h3>
                <h4>Doctor, invester</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Provides you advanced and long-lasting services. Our team always remains ready to provide you better
                  services in shorter time. Your security is first attention of our team.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-006.jpg" class="testimonial-img" alt="">
                <h3>Lokesh verma</h3>
                <h4>Busniessmen</h4>
              </div>
            </div><!-- End testimonial item -->

            <!--<div class="swiper-slide">-->
            <!--  <div class="testimonial-item">-->
            <!--    <p>-->
            <!--      <i class="bx bxs-quote-alt-left quote-icon-left"></i>-->
            <!--      Facilitator, a position within an organization or business with significant responsibilities for-->
            <!--      acting as a liaison between departments, stakeholders and information-->
            <!--      <i class="bx bxs-quote-alt-right quote-icon-right"></i>-->
            <!--    </p>-->
            <!--    <img src="assets/img/testimonials/testimonials-0044.jfif" class="testimonial-img" alt="">-->
            <!--    <h3>Er. Divya Patel</h3>-->
            <!--    <h4>Coordinator</h4>-->
            <!--  </div>-->
            <!--</div><!-- End testimonial item -->-->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  we are providing you a platform where you can join us and take a training of some of the various
                  services we provide and join us to create a better future for you.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-005.jpg" class="testimonial-img" alt="">
                <h3>Er. Shubham Verma</h3>
                <h4>Entrepreneur</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Our team always remains ready to provide you better
                  services in shorter time. Your security is first attention of our team.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-0099.jpg" class="testimonial-img" alt="">
                <h3>Er. Swati Malik</h3>
                <h4>Coordinator</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Our team always remains ready to provide you better
                  services in shorter time. Your security is first attention of our team.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-0088.jpeg" class="testimonial-img" alt="">
                <h3>Tarun verma</h3>
                <h4>Coordinator</h4>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Doctors Section ======= -->
    <section id="doctors" class="doctors section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Team</h2>
          <p>We utilize your feedback to improve quality of our services.</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="assets/img/doctors/doctors-0030.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Dr. Bhuvneshwer jnaghela</h4>
                <span>Doctor</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="200">
              <div class="member-img">
                <img src="assets/img/doctors/doctors-0040.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Dr. Ishwari Verma</h4>
                <span>Doctor</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="300">
              <div class="member-img">
                <img src="assets/img/doctors/doctors-003.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Shubham Verma</h4>
                <span>Entrepreneur</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="400">
              <div class="member-img">
                <img src="assets/img/doctors/doctors-006.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Lokesh Verma</h4>
                <span>Distributor</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Doctors Section -->

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Gallery</h2>
          <p>Our team always remains ready to provide you better services in shorter time. Your security is first
            attention of our team.</p>
        </div>

        <div class="gallery-slider swiper-container">
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-001.jpg"><img
                  src="assets/img/gallery/gallery-001.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-2.jpg"><img
                  src="assets/img/gallery/gallery-2.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-003.jpg"><img
                  src="assets/img/gallery/gallery-003.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-004.jpg"><img
                  src="assets/img/gallery/gallery-004.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-5.jpg"><img
                  src="assets/img/gallery/gallery-5.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-6.jpg"><img
                  src="assets/img/gallery/gallery-6.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-7.jpg"><img
                  src="assets/img/gallery/gallery-7.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-008.jpg"><img
                  src="assets/img/gallery/gallery-008.jpg" class="img-fluid" alt=""></a></div>
            <div class="swiper-slide"><a class="gallery-lightbox" href="assets/img/gallery/gallery-9.jpg"><img
                  src="assets/img/gallery/gallery-9.jpg" class="img-fluid" alt=""></a></div>
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Gallery Section -->

    <!-- ======= Pricing Section ======= -->
    <!--<section id="pricing" class="pricing">-->
    <!--  <div class="container" data-aos="fade-up">-->

    <!--    <div class="section-title">-->
    <!--      <h2>Pricing</h2>-->
    <!--      <p>A pricing strategy is a model or method used to establish the best price for a product or service.</p>-->
    <!--    </div>-->

    <!--    <div class="row">-->

    <!--      <div class="col-lg-3 col-md-6">-->
    <!--        <div class="box" data-aos="fade-up" data-aos-delay="100">-->
    <!--          <h3>Free</h3>-->
    <!--          <h4><sup>₹</sup>00<span> / month</span></h4>-->
    <!--          <ul>-->
    <!--            <li class="na">Aida dere</li>-->
    <!--            <li class="na">Nec feugiat nisl</li>-->
    <!--            <li class="na">Nulla at volutpat dola</li>-->
    <!--            <li class="na">Pharetra massa</li>-->
    <!--            <li class="na">Massa ultricies mi</li>-->
    <!--          </ul>-->
    <!--          <div class="btn-wrap">-->
    <!--            <a href="#" class="btn-buy">Buy Now</a>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->

    <!--      <div class="col-lg-3 col-md-6 mt-4 mt-md-0">-->
    <!--        <div class="box featured" data-aos="fade-up" data-aos-delay="200">-->
    <!--          <h3>Business</h3>-->
    <!--          <h4><sup>₹</sup>00<span> / month</span></h4>-->
    <!--          <ul>-->
    <!--            <li class="na">Aida dere</li>-->
    <!--            <li class="na">Nec feugiat nisl</li>-->
    <!--            <li class="na">Nulla at volutpat dola</li>-->
    <!--            <li class="na">Pharetra massa</li>-->
    <!--            <li class="na">Massa ultricies mi</li>-->
    <!--          </ul>-->
    <!--          <div class="btn-wrap">-->
    <!--            <a href="#" class="btn-buy">Buy Now</a>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->

    <!--      <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">-->
    <!--        <div class="box" data-aos="fade-up" data-aos-delay="300">-->
    <!--          <h3>Developer</h3>-->
    <!--          <h4><sup>₹</sup>00<span> / month</span></h4>-->
    <!--          <ul>-->
    <!--            <li class="na">Aida dere</li>-->
    <!--            <li class="na">Nec feugiat nisl</li>-->
    <!--            <li class="na">Nulla at volutpat dola</li>-->
    <!--            <li class="na">Pharetra massa</li>-->
    <!--            <li class="na">Massa ultricies mi</li>-->
    <!--          </ul>-->
    <!--          <div class="btn-wrap">-->
    <!--            <a href="#" class="btn-buy">Buy Now</a>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->

    <!--      <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">-->
    <!--        <div class="box" data-aos="fade-up" data-aos-delay="400">-->
    <!--          <span class="advanced">Advanced</span>-->
    <!--          <h3>Ultimate Services</h3>-->
    <!--          <h4><sup>₹</sup>00<span> / month</span></h4>-->
    <!--          <ul>-->
    <!--            <li class="na">Aida dere</li>-->
    <!--            <li class="na">Nec feugiat nisl</li>-->
    <!--            <li class="na">Nulla at volutpat dola</li>-->
    <!--            <li class="na">Pharetra massa</li>-->
    <!--            <li class="na">Massa ultricies mi</li>-->
    <!--          </ul>-->
    <!--          <div class="btn-wrap">-->
    <!--            <a href="#" class="btn-buy">Buy Now</a>-->
    <!--          </div>-->
    <!--        </div>-->
    <!--      </div>-->

    <!--    </div>-->

    <!--  </div>-->
    <!--</section>-->
    <!-- End Pricing Section -->

    <!-- ======= Frequently Asked Questioins Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questioins</h2>
          <p>The letters FAQ stands for Frequently Asked Questions. A FAQ page is usually a list of common
            questions people have asked about a specific product or service.</p>
        </div>

        <ul class="faq-list">

          <li>
            <div data-bs-toggle="collapse" class="collapsed question" href="#faq1">COVID-19 affects different people in
              different ways? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i>
            </div>
            <div id="faq1" class="collapse" data-bs-parent=".faq-list">
              <p>
                Most common symptoms:
                fever,
                dry cough,
                tiredness &
                Less common symptoms:
                aches and pains,
                sore throat,
                diarrhoea,
                conjunctivitis,
                headache,
                loss of taste or smell,
                a rash on skin, or discolouration of fingers or toes &
                Serious symptoms:
                difficulty breathing or shortness of breath,
                chest pain or pressure,
                loss of speech or movement,
              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq2" class="collapsed question">When do side effects of covid-19
              vaccine start? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i>
            </div>
            <div id="faq2" class="collapse" data-bs-parent=".faq-list">
              <p>
                When exactly symptoms set in following your dose will vary from person to person, but Adams generalizes
                that you can expect your side effects to hit within 24 hours of your dose, and not to stretch 7 days
                post your vaccination.
              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq3" class="collapsed question">What are foods to avoid during the
              COVID-19 pandemic? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i>
            </div>
            <div id="faq3" class="collapse" data-bs-parent=".faq-list">
              <p>
                Reduce foods such as red and fatty meats, butter and full-fat dairy products, palm oil, coconut oil,
                solid shortening and lard. Avoid trans fats as much as possible. Read nutrition labels to ensure that
                partially hydrogenated oils are not listed in the ingredients.

                If food labels are not available, avoid foods which commonly contain trans fats such as processed and
                fried foods, like doughnuts and baked goods – including biscuits, pie crusts, frozen pizzas, cookies,
                crackers and margarines that include partially hydrogenated fat.

                If in doubt, minimally processed foods and ingredients are better choices. Consume enough fibre Fibre
                contributes to a healthy digestive system and offers a prolonged feeling of fullness, which helps
                prevent overeating.
              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq4" class="collapsed question">What are the recommended preventive
              measures for COVID-19? <i class="bi bi-chevron-down icon-show"></i><i
                class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq4" class="collapse" data-bs-parent=".faq-list">
              <p>
                Recommended preventive measures include social distancing, wearing a face mask in public, ventilation
                and air-filtering, hand washing, covering one's mouth when sneezing or coughing, disinfecting surfaces,
                and monitoring and self-isolation for people exposed or symptomatic.
              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq5" class="collapsed question">What are some of the emergency
              warning signs for someone with the coronavirus disease? <i class="bi bi-chevron-down icon-show"></i><i
                class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq5" class="collapse" data-bs-parent=".faq-list">
              <p>
                Call a doctor or hospital right away if you have one or more of these COVID-19 symptoms: Trouble
                breathing. Constant pain or pressure in your chest. Bluish lips or face.
              </p>
            </div>
          </li>

          <li>
            <div data-bs-toggle="collapse" href="#faq6" class="collapsed question">Can the coronavirus disease be
              transmitted in hot or humid climates? <i class="bi bi-chevron-down icon-show"></i><i
                class="bi bi-chevron-up icon-close"></i></div>
            <div id="faq6" class="collapse" data-bs-parent=".faq-list">
              <p>
                From the evidence so far, the COVID-19 virus can be transmitted in ALL AREAS, including areas with hot
                and humid weather. Regardless of climate, adopt protective measures if you live in, or travel to an area
                reporting COVID-19. The best way to protect yourself against COVID-19 is by frequently cleaning your
                hands. By doing this you eliminate viruses that may be on your hands and avoid infection that could
                occur by then touching your eyes, mouth, and nose.
              </p>
            </div>
          </li>

        </ul>

      </div>
    </section><!-- End Frequently Asked Questioins Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
          <p>we provide and join us to create a better future for you. If you want to learn your new work and change
            your
            life then come join us in our training program with a small amount and after training, we will prepare you
            for
            services in our company and make your life a Will provide the path.</p>
        </div>

      </div>

      <div>
        <iframe style="border:0; width: 100%; height: 350px;"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14790.082407146647!2d78.8991787188854!3d22.067926652893444!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd565ec995374f5%3A0xa7d715229331a600!2sVishnu%20Nagar%2C%20Chhindwara%2C%20Madhya%20Pradesh%20480001!5e0!3m2!1sen!2sin!4v1620542067126!5m2!1sen!2sin"
          frameborder="0" allowfullscreen></iframe>
      </div>

      <div class="container">

        <div class="row mt-5">

          <div class="col-lg-6">

            <div class="row">
              <div class="col-md-12">
                <div class="info-box">
                  <i class="bx bx-map"></i>
                  <h3>Our Address</h3>
                  <p>Near Krishna Tower, INDIA, CWA 480001</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-envelope"></i>
                  <h3>Email Us</h3>
                  <p>info@starinfosl.com<br>Starinfosl954@gmail.com</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-phone-call"></i>
                  <h3>Call Us</h3>
                  <p>+91 9074919296<br>+91 9669463203</p>
                </div>
              </div>
            </div>

          </div>

          <div class="col-lg-6">
            <form id="my-form" action="https://formspree.io/f/xayaqgyk" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col form-group mt-3">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col form-group mt-3">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <!--<div class="my-3">-->
              <!--  <div class="loading">Loading</div>-->
              <!--  <div class="error-message"></div>-->
              <!--  <div class="sent-message">Your message has been sent. Thank you!</div>-->
              <!--</div>-->
              <div class="text-center"><button id="my-form-button" type="submit">Send Message</button></div>
              <p class="text-center my-3" data-aos="zoom-in" id="my-form-status"></p>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
              <h3>Starinfosol</h3>
              <p>
                Near, Krishna Tower <br>
                CWA 480001, INDIA<br><br>
                <strong>Phone:</strong> +91 9074919296<br>
                <strong>Email:</strong> info@starinfosol.com<br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <!-- <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a> -->
                <!-- <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a> -->
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
                <a href="https://wa.me/message/H72CPSV3OZMAE1" class="whatsapp"><i class="bx bxl-whatsapp"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#hero">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#about">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="Terms_conditions.html">Terms & Conditions</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="Terms_conditions.html">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Project</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Customers</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>Starinfosol mission is to offer residents of the Local area the best service in the area.</p>
            <form action="login.php" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
            <br>
            <a href="logout.php" type="button" data-toggle="modal" class="m-0 appointment-btn scrollto"><span class="d-none d-md-inline"></span>Logout</a>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Starinfosol</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/medicio-free-bootstrap-theme/ -->
        Designed by <a href="https://starinfosol.com/">Starinfosol</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  
  <script>
    var form = document.getElementById("my-form");
    
    async function handleSubmit(event) {
      event.preventDefault();
      var status = document.getElementById("my-form-status");
      var data = new FormData(event.target);
      fetch(event.target.action, {
        method: form.method,
        body: data,
        headers: {
            'Accept': 'application/json'
        }
      }).then(response => {
        status.innerHTML = "Your message has been sent. Thank you!";
        form.reset()
      }).catch(error => {
        status.innerHTML = "Oops! There was a problem submitting your form"
      });
    }
    form.addEventListener("submit", handleSubmit)
</script>

<script>
    var form = document.getElementById("appointment-form");
    
    async function handleSubmit(event) {
      event.preventDefault();
      var status1 = document.getElementById("appointment-form-status");
      var data = new FormData(event.target);
      fetch(event.target.action, {
        method: form.method,
        body: data,
        headers: {
            'Accept': 'application/json'
        }
      }).then(response => {
        status1.innerHTML = "Your Appointment is booked. We will response you as soon as possible. Thank you!";
        form.reset()
      }).catch(error => {
        status1.innerHTML = "Oops! There was a problem submitting your Appointment form"
      });
    }
    form.addEventListener("submit", handleSubmit)
</script>


</body>

</html>