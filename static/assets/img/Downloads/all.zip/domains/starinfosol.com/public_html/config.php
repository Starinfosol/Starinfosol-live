<?php 

$server = "127.0.0.2";
$user = "starinf1_login";
$pass = "Starinfosol@0954#$%^&";
$database = "starinf1_login";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}

?>